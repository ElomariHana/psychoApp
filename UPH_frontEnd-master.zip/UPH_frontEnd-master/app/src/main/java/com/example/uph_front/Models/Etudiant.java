package com.example.uph_front.Models;

public class Etudiant {
    private int id;
    private User user;
    private String cne;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getCne() {
        return cne;
    }

    public void setCne(String cne) {
        this.cne = cne;
    }

    @Override
    public String toString() {
        return "Etudiant{" +
                "id=" + id +
                ", user=" + user +
                ", cne='" + cne + '\'' +
                '}';
    }
}
