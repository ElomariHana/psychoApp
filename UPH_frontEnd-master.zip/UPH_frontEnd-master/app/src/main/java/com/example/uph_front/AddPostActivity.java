package com.example.uph_front;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.uph_front.Fragments.HomeFragment;
import com.example.uph_front.Models.Post;
import com.example.uph_front.Models.User;


import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class AddPostActivity extends AppCompatActivity {
    private Button btnPost;
    private ImageView imgAddPost;
    private EditText txtDescAddPost,title;
    private Bitmap bitmap=null;
    private ProgressDialog dialog;
    private static final int GALLERY_CHANGE_POST=4;
    private SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_post);
        init();
    }

    private void init() {
        sharedPreferences=getApplication().getApplicationContext().getSharedPreferences("user",Context.MODE_PRIVATE);
        btnPost =(Button) findViewById(R.id.btnSave);
        imgAddPost =(ImageView) findViewById(R.id.imgAddPost);
        txtDescAddPost = findViewById(R.id.post_content);
        dialog=new ProgressDialog(this);
        dialog.setCancelable(false);
        title=findViewById(R.id.add_title);

        /*imgAddPost.setImageURI(getIntent().getData());
        try {
            bitmap= MediaStore.Images.Media.getBitmap(getContentResolver(),getIntent().getData());
        } catch (IOException e) {
            e.printStackTrace();
        }*/

        btnPost.setOnClickListener(view -> {
            if(!txtDescAddPost.getText().toString().isEmpty()){
                post();
            }
        });

    }

    private void post() {
        String desc= txtDescAddPost.getText().toString().trim();
        String titre= title.getText().toString().trim();
        dialog.setMessage("Posting ...");
        dialog.show();
        StringRequest request=new StringRequest(Request.Method.POST,Constant.ADD_POST,response -> {

            try {
                JSONObject object=new JSONObject(response);
                if (object.getBoolean("success")){

                    JSONObject postObject = object.getJSONObject("post");
                    JSONObject userObject = postObject.getJSONObject("user");

                    User user = new User();
                    user.setId(userObject.getInt("id"));
                    user.setUserName(userObject.getString("name"));
                    user.setPhoto(userObject.getString("photo"));

                    Post post = new Post();
                    post.setUser(user);
                    post.setId(postObject.getInt("id"));
                    post.setSelfLike(false);


                    if (!postObject.getString("photo").isEmpty()){
                        post.setPhoto(postObject.getString("photo"));
                    }else{
                        post.setPhoto("");
                    }

                    post.setDesc(postObject.getString("desc"));
                    post.setTitle(postObject.getString("title"));
                    post.setComments(0);
                    post.setLikes(0);
                    post.setDate(postObject.getString("created_at"));

                    HomeFragment.arrayList.add(0,post);
                    HomeFragment.recyclerView.getAdapter().notifyItemInserted(0);
                    HomeFragment.recyclerView.getAdapter().notifyDataSetChanged();
                    Toast.makeText(this, "Posted", Toast.LENGTH_SHORT).show();
                    finish();


                }
            } catch (JSONException e) {
                e.printStackTrace();
                dialog.dismiss();

            }

        },error -> {
            error.printStackTrace();
            dialog.dismiss();
        }){
            //add token to header

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                String token= sharedPreferences.getString("token","");
                HashMap<String,String> map= new HashMap<>();
                map.put("Authorization","Bearer"+token);
                return map;
            }


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> map= new HashMap<>();
                map.put("desc",desc);
                map.put("title",titre);
                map.put("photo",bitmapToString(bitmap));
                return map;
            }
        };
        RequestQueue queue= Volley.newRequestQueue(AddPostActivity.this);
        queue.add(request);

    }

    private String bitmapToString(Bitmap bitmap) {
        if(bitmap!=null){
            ByteArrayOutputStream byteArrayOutputStream=new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG,100,byteArrayOutputStream);
            byte[] array=byteArrayOutputStream.toByteArray();
            return Base64.encodeToString(array,Base64.DEFAULT);
        }
        return "";
    }

    public void cancelPost(View view) {
        super.onBackPressed();
    }

    public void changePhoto(View view) {
        Intent i= new Intent(Intent.ACTION_PICK);
        i.setType("image/*");
        startActivityForResult(i,GALLERY_CHANGE_POST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==GALLERY_CHANGE_POST && resultCode==RESULT_OK){
            Uri imgUri1 =data.getData();
            imgAddPost.setImageURI(imgUri1);
            try {
                bitmap= MediaStore.Images.Media.getBitmap(getContentResolver(),imgUri1);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void cancelEdit(View view) {
        super.onBackPressed();
    }


    public void canceleditpost(View view) {
        onBackPressed();
    }
}