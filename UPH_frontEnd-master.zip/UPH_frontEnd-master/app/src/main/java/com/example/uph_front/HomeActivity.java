package com.example.uph_front;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.uph_front.Fragments.AccountFragement;
import com.example.uph_front.Fragments.EtudiantFragement;
import com.example.uph_front.Fragments.HomeFragment;
import com.example.uph_front.Models.Etudiant;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    private MaterialToolbar toolbar;
    private DrawerLayout drawerLayout;
    private NavigationView navigationViewTop;
    private FragmentManager fragmentManager;

    private FloatingActionButton fab;
    private BottomNavigationView navigationView;
    private SharedPreferences preferences;
    private Uri imgUri;

    private static final int GALLERY_ADD_POST = 3;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        ////////////////////////
        this.configureToolBar();
        this.configureDrawerLayout();
        this.configureNavigationView();
        /////////////////////////



        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frameHomeContainer,new HomeFragment(), HomeFragment.class.getSimpleName()).commit();
        init();
    }





    private void init() {
        navigationView = findViewById(R.id.bottom_nav);
        preferences = this.getSharedPreferences("user", Context.MODE_PRIVATE);


        fab = findViewById(R.id.fab);
        fab.setOnClickListener(v->{

            startActivity(new Intent(HomeActivity.this,AddPostActivity.class));
            /*Intent i = new Intent(Intent.ACTION_PICK);
            i.setType("image/*");
            startActivityForResult(i,GALLERY_ADD_POST);*/
        });




        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()){
                    case R.id.item_home: {
                        fragmentManager = getSupportFragmentManager();
                        fragmentManager.beginTransaction().replace(R.id.frameHomeContainer,new HomeFragment(), HomeFragment.class.getSimpleName()).commit();
                        fab.setVisibility(View.VISIBLE);
                        toolbar.setTitle("Posts");
                        break;
                    }

                    case R.id.item_account: {
                        fragmentManager = getSupportFragmentManager();
                        fragmentManager.beginTransaction().replace(R.id.frameHomeContainer,new EtudiantFragement(), Etudiant.class.getSimpleName()).commit();
                        toolbar.setTitle("Archives");
                        fab.setVisibility(View.GONE);
                        break;
                    }
                }

                return  true;
            }
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==GALLERY_ADD_POST && resultCode==RESULT_OK){
            imgUri = data.getData();
            System.out.println("---------------------->"+imgUri);
            Toast.makeText(this,""+imgUri,Toast.LENGTH_SHORT);
            Intent i = new Intent(HomeActivity.this,AddPostActivity.class);
            i.setData(imgUri);
            startActivity(i);
        }
    }

    @Override
    public void onBackPressed() {
        // 5 - Handle back click to close menu
        if (this.drawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        // 4 - Handle Navigation Item Click
        int id = item.getItemId();
        if(preferences.getString("role","").equals("Professor")){

            switch (id){


                case R.id.activity_main_drawer_profile:
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.frameHomeContainer,new AccountFragement(), AccountFragement.class.getSimpleName()).commit();
                    toolbar.setTitle("Profil");
                    fab.setVisibility(View.GONE);

                    break;
                case R.id.activity_main_drawer_home:
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.frameHomeContainer,new HomeFragment(), AccountFragement.class.getSimpleName()).commit();
                    toolbar.setTitle("Posts");
                    fab.setVisibility(View.VISIBLE);
                    break;
                case R.id.activity_main_drawer_about_us:
                    startActivity(new Intent(HomeActivity.this,About_us.class));
                    break;
                case R.id.activity_main_drawer_archive:
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.frameHomeContainer,new EtudiantFragement(), Etudiant.class.getSimpleName()).commit();
                    toolbar.setTitle("Archives");
                    fab.setVisibility(View.GONE);
                    break;
                case R.id.activity_main_drawer_sign_out:
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage("Do you want to logout?");
                    builder.setPositiveButton("Logout", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            logout();
                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    builder.show();
                    break;

                default:
                    Toast.makeText(this,"this for students",Toast.LENGTH_SHORT).show();

                    break;
            }


        }else{
            switch (id){


                case R.id.activity_main_drawer_profile:
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.frameHomeContainer,new AccountFragement(), AccountFragement.class.getSimpleName()).commit();
                    toolbar.setTitle("Profil");
                    fab.setVisibility(View.GONE);
                    break;
                case R.id.activity_main_drawer_home:
                    fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.frameHomeContainer,new HomeFragment(), AccountFragement.class.getSimpleName()).commit();
                    toolbar.setTitle("Posts");
                    fab.setVisibility(View.VISIBLE);
                    break;
                case R.id.activity_main_drawer_about_us:
                    startActivity(new Intent(HomeActivity.this,About_us.class));
                    break;

                case R.id.activity_main_drawer_sign_out:
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage("Do you want to logout?");
                    builder.setPositiveButton("Logout", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            logout();
                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    builder.show();
                    break;

                default:
                    Toast.makeText(this,"You don't have access to this choice",Toast.LENGTH_SHORT).show();

                    break;
            }

        }


        this.drawerLayout.closeDrawer(GravityCompat.START);

        return true;
    }

    // ---------------------
    // CONFIGURATION
    // ---------------------

    // 1 - Configure Toolbar
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void configureToolBar(){
        this.toolbar = (MaterialToolbar) findViewById(R.id.activity_main_toolbar);
        setSupportActionBar(toolbar);
    }

    // 2 - Configure Drawer Layout
    private void configureDrawerLayout(){
        this.drawerLayout = (DrawerLayout) findViewById(R.id.activity_main_drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
    }

    // 3 - Configure NavigationView
    private void configureNavigationView(){
        this.navigationViewTop = (NavigationView) findViewById(R.id.activity_main_nav_view);
        navigationViewTop.setNavigationItemSelectedListener(this);
    }

    private void logout(){
        StringRequest request = new StringRequest(Request.Method.GET,Constant.LOGOUT, res->{

            try {
                JSONObject object = new JSONObject(res);
                if (object.getBoolean("success")){
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.clear();
                    editor.apply();
                    startActivity(new Intent(((HomeActivity)this), AuthActivity.class));
                    ((HomeActivity)this).finish();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }


        },error -> {
            error.printStackTrace();
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                String token = preferences.getString("token","");
                HashMap<String,String> map = new HashMap<>();
                map.put("Authorization","Bearer "+token);
                return map;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }
}




