package com.example.uph_front.Fragments;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.uph_front.Adapters.EtudiantAdapter;
import com.example.uph_front.Constant;
import com.example.uph_front.HomeActivity;
import com.example.uph_front.Models.Post;
import com.example.uph_front.Models.User;
import com.example.uph_front.R;
import com.google.android.material.appbar.MaterialToolbar;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class AccountFragement extends Fragment {
    View view;
    private RecyclerView recyclerViewTest;
    private ArrayList<User> arrayListUser;
    private SwipeRefreshLayout refreshLayout;
    private EtudiantAdapter UsersAdapter;
    //private Toolbar toolbar;
    private MaterialToolbar toolbar;
    private SharedPreferences sharedPreferences;

    private CircleImageView imgProfile;
    private TextView txtName,txtEmail;
    private Button btnEditAccount;
    private RecyclerView recyclerView;

    private SharedPreferences preferences;
    private String imgUrl = "";





    public AccountFragement(){}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view= inflater.inflate(R.layout.layout_account,container,false);
        init();

        return view;
    }


    private void init() {
        User user=new User();
        preferences = getContext().getSharedPreferences("user", Context.MODE_PRIVATE);
        toolbar = view.findViewById(R.id.toolbarAccount);
        ((HomeActivity)getContext()).setSupportActionBar(toolbar);
        setHasOptionsMenu(true);
        txtEmail=(TextView) view.findViewById(R.id.txtAccountEmail);
        imgProfile = view.findViewById(R.id.imgAccountProfile);
        txtName = view.findViewById(R.id.txtAccountName);


        btnEditAccount = view.findViewById(R.id.btnEditAccount);


        txtName.setText(preferences.getString("name",""));
        txtEmail.setText(preferences.getString("email",""));

        Picasso.get().load(Constant.URL+"/storage/profiles/"+preferences.getString("photo","")).into(imgProfile);


    }
}
