package com.example.uph_front;

public class Constant {

    public static String URL= "http://192.168.43.26:80";
    //public static String URL= "https://backenddevmobile.herokuapp.com";
    //public static String URL= "http://192.168.0.113";
    public static String HOME=URL+"/api";
    public static String REGISTER=HOME+"/register";
    public static String LOGIN=HOME+"/login";
    public static final String LOGOUT = HOME+"/logout";
    public static String SAVE_USER_INFO=HOME+"/saveUserInfo";
    public static String POSTS=HOME+"/posts";
    //public static String GET_USERS=HOME+"/getAllUsers";
    public static String ADD_POST=HOME+"/post/create";
    public static final String EDIT_POST=HOME+"/post/update";
    public static final String LIKE_POST = HOME+"/post/like";
    public static final String DELETE_POST =HOME+"/post/delete";
    public static String GET_STUDENTS=HOME+"/etudiants";


/*
    public static final String URL = "http://192.168.1.108:80/";
    public static final String HOME = URL+"api";
    public static final String LOGIN = HOME+"/login";

    public static final String REGISTER = HOME+"/register";
    public static final String SAVE_USER_INFO = HOME+"/saveUserInfo";
   /* public static final String POSTS = HOME+"/posts";
    public static final String ADD_POST = POSTS+"/create";
    public static final String UPDATE_POST = POSTS+"/update";


    public static final String COMMENTS = POSTS+"/comments";
    public static final String CREATE_COMMENT = HOME+"/comments/create";
    public static final String DELETE_COMMENT = HOME+"/comments/delete";
    public static final String MY_POST = POSTS+"/my_posts";*/

}
