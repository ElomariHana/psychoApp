<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateArchifsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('archifs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('id_etud');
            $table->unsignedBigInteger('id_prof');
            $table->timestamps();
            
            $table->foreign('id_etud')->references('id')
            ->on('etudiants')->onDelete('cascade');
            $table->foreign('id_prof')->references('id')
            ->on('profs')->onDelete('cascade');
        });

       
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('archifs');
    }
}
