<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Login (All shecked )
Route::post('login', 'Api\AuthController@login');
Route::post('register', 'Api\AuthController@register');
Route::post('logout', 'Api\AuthController@logout');
Route::get('getAllUsers', 'Api\AuthController@getAllUsers');
Route::post('saveUserInfo', 'Api\AuthController@saveUserInfo')->middleware('jwtAuth');


//POST CRUD
Route::post('post/create/', 'Api\PostsController@create')->middleware('jwtAuth');
Route::post('post/update/', 'Api\PostsController@update')->middleware('jwtAuth');
Route::POST('post/delete/', 'Api\PostsController@delete')->middleware('jwtAuth');
Route::get('posts', 'Api\PostsController@posts')->middleware('jwtAuth');

// Comments 
Route::post('comment/create', 'Api\CommentController@create')->middleware('jwtAuth');
Route::post('comment/commentReply', 'Api\CommentController@commentReply')->middleware('jwtAuth');
Route::post('GetReplys', 'Api\CommentController@GetReplys')/*->middleware('jwtAuth')*/;



//LIKE CRUD
Route::POST('post/like', 'Api\LikesController@like')->middleware('jwtAuth');
Route::post('login','api\AuthController@login');


//prof*
Route::post('prof/create','api\ProfsController@create')->middleware('jwtAuth');

/*
//etudiant*
Route::post('etudiants','api\EtudiantController@etudiants');
Route::post('etudiant/create','api\EtudiantController@create')->middleware('jwtAuth');
Route::post('etudiant/update','api\EtudiantController@update')->middleware('jwtAuth');
Route::post('etudiant/delete','api\EtudiantController@delete')->middleware('jwtAuth');
*/

//Classeurs
Route::post('classeurs/create','api\ClasseursController@create');
Route::post('classeurs/update','api\ClasseursController@update');
Route::post('classeurs/delete','api\ClasseursController@delete');
Route::post('classeurs','api\ClasseursController@classeurs');
//Archif
Route::post('archifs/create/','api\ArchifsController@create');
Route::post('archifs/delete','api\ArchifsController@delete');
Route::get('archifs','api\ArchifsController@archifs');

//file

// ETUDIANT CRUD
Route::POST('etudiant/create','Api\EtudiantController@create')->middleware('jwtAuth');
Route::POST('etudiant/delete','Api\EtudiantController@delete');
Route::GET('etudiants','Api\EtudiantController@etudiants');
Route::POST('etudiant/update','Api\EtudiantController@update');

// PROF CRUD 'No need for it
/*Route::POST('prof/create','Api\ProfController@create');
Route::POST('prof/delete','Api\ProfController@delete');
Route::GET('profs','Api\ProfController@profs');
Route::POST('prof/update','Api\ProfController@update');*/

