<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Archif;
use Auth;
use App\Prof;
class ArchifsController extends Controller
{
public function create(Request $request){
    $archif = new Archif;
    //auth prof =prof find auth id_user
    $archif->id_etud = $request->id_etud;
    //$prof =Prof::where('id_user',Auth::user()->id)->first();
    $archif->id_prof  = Auth::user()->id ;
   // $archif->id_prof = $request->id_prof;
    $archif->save();
    return response()->json ([
        
        'success' => true,
        'message' => 'archife added',
        'archif' =>  $archif


    ]);
}
public function archifs(Request $request){
    $archifs = Archif::where('id_prof',$request->id)->get();
   // foreach($archifs as $archif)
   return response()->json ([
        
    'success' => true,
    'message' => 'get',
    'archif' =>  $archifs


]);
   
}
public function delete(Request $request){
    $archif = Archif::find($request->id);
   

    $archif->delete();
    return response()->json ([
        
        'success' => true,
        'message' => 'archif delete',
        'archif' =>  $archif


    ]);
}

}