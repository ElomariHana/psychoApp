<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\File;
class FileUpload extends Controller
{
    public function createForm(){
        return view('file-upload');
      }
      public function fileUpload(Request $req){
        $req->validate([
        'file' => 'required|mimes:csv,txt,xlx,xls,pdf|max:2048'
        ]);

        $fileModel = new File;

        if($req->file()) {
            $fileName = time().'_'.$req->file->getClientOriginalName();
            $filepath = $req->file('file')->storeAs('uploads', $fileName, 'public');

            $fileModel->title = time().'_'.$req->file->getClientOriginalName();
            $fileModel->filepath = '/storage/files' . $filepath;
            $fileModel->save();

            return back()
            ->with('success','File has been uploaded.')
            ->with('file', $fileName);
        }
   }
}
