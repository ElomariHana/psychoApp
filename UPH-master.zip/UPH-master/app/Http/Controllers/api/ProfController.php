<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Prof;

class ProfController extends Controller
{
    public function profs(){
        $profs=Prof::all();
    	return response()->json([
                    'success'=>true,
                    'prof'=>$profs
                ]); 
    }
    
    //Create
    public function create($matricule , $user_id){
    	$prof= new Prof;
    	$prof->id_user= $user_id;
    	$prof->matricule= $matricule;
    	$prof->save();

    	 return response()->json([
                    'success'=>true,
                    'prof'=>$prof
                ]); 
    }

    //Update

    public function update(Request $req,Prof $id ){
    	$prof=Prof::find($req->id);
    	$prof->user_id=$req->user_id;
    	$prof->matricule=$req->matricule;
    	$prof->update();
    	return response()->json([
    		'success'=>true,
    		'prof'=>$prof
    	]);

    }

    //Delete
    public function delete(Request $req, Prof $id){
    	$prof=Prof::find($req->id);
    	$prof->delete();
    	return response()->json([
    		'message'=>'deleted'
    	]);
    }
}
