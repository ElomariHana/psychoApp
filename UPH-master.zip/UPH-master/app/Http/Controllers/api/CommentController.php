<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Comment;
use App\Post;
use Auth;
class CommentController extends Controller
{
    public function create(Request $request){
        $post = Post::find($request->id);
        $comment = new Comment;
        $comment->user_id = Auth::user()->id;
        $comment->content = $request->content;
        $post->comments()->save($comment);
        return response()->json([
            'success'=>true,
            'post'=>$post,
            'comment'=>$comment,
            'user_name'=>$comment->user->name
        ]); 
    }

    public function commentReply(Request $request){
        $comment = Comment::find($request->id);
        $commentReply = new Comment;
        $commentReply->user_id = Auth::user()->id;
        $commentReply->content = $request->content;
        $comment->comments()->save($commentReply);
        return response()->json([
            'success'=>true,
            'comment'=>$comment,
            'user_name'=>$comment->user->name,
            'reply'=> $commentReply
        ]); 
    }


    // Get Replys of an given Comment
    public function GetReplys(Request $request){
        $comment = Comment::find($request->id);
        $commentReplys = $comment->comments;
        return response()->json([
            'success' => true,
            'replays' => $commentReplys
        ]);
    }
    
 /*   // Get Replys of an given Comment
    public function GetReplys($comment){
        $commentReplys = $comment->comments;
        return response()->json([
            'success' => true,
            'replays' => $commentReplys
        ]);
    }*/
}
