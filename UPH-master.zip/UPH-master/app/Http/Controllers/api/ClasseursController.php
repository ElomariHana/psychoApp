<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Classeur;
class ClasseursController extends Controller
{
    public function create(Request $request){
        $classeur = new Classeur;
        $classeur->contenue = $request->contenue;
        $classeur->id_archif = $request->id;
        $classeur->save();

        return response()->json ([
            
            'success' => true,
            'message' => 'classeur added'
        ]);
    }
    public function update(Request $request){
        $classeur = Classeur::find($request->id);
    
        $classeur->contenue = $request->contenue;
        $classeur->update();
        return response()->json ([
            
            'success' => true,
            'message' => 'classeurs edited',
            'classeur' =>  $classeur


        ]);
    }
    public function delete(Request $request){
        $classeur = Classeur::find($request->id);
       

        $classeur->delete();
        return response()->json ([
            
            'success' => true,
            'message' => 'classeurs delete',
            'classeur' =>  $classeur


        ]);
    }
    public function classeurs(Request $request){
        $classeurs = Classeur::where('id',$request->id)->get();
       // foreach($archifs as $archif)
       return response()->json ([
            
        'success' => true,
        'message' => 'get',
        'classeurs' =>  $classeurs
    
    
    ]);
       
    }

}
