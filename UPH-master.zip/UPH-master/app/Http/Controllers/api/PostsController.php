<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Post;
use Auth;
use Storage;
use App\Comment;


class PostsController extends Controller
{



        public function posts(){
                $posts=Post::orderBy('id','desc')->get();
                foreach($posts as $post){
                //get user of post
                    $post->user;
                 //commentCount
                 $post['commentsCount']=count($post->comments);
                 //$post['commentsCount']=356;
                 //likes count
                 $post['likesCount']=count($post->likes);
                    //$post['likesCount']=3344;
                 //check if user like his oun post
                 $post['selfLike']=false;
                 foreach($post->likes as $like){
                     if($like->user_id==Auth::user()->id){
                     $post['selfLike']=true;
                     }
                 }
                 foreach($post->comments as $comment){
                     $posts['comment'] = $comment;
                     $posts['comment']['replays']= $comment->comments;
                 }
                }
                return response()->json([
                    'success'=>true,
                    'posts'=>$posts
                ]); 
            }


    public function create(Request $request){
        $post=new Post;
        try{
        $post->user_id=Auth::user()->id;
        //photo
        if($request->photo!=''){
        $photo=time().'.jpg';
        file_put_contents('storage/posts/'.$photo,base64_decode($request->photo));
        $post->photo=$photo;
        
        }
        $post->desc=$request->desc;
        $post->title=$request->title;
        $post->save();
        return  response()->json([
            'success'=>true,
            'post'=>$post,
            'user'=>$post->user
        ]);
         
        }catch(Exception $e){

        return response()->json([
            'success'=>false,
            'error'=>$e
        ]);
        }
    }

    public function update(Request $request){

    $post=Post::find($request->id);
    if(Auth::user()->id != $post->user_id){
        return response()->json([

        "success"=>false,
        "message"=>"unautorized access"


        ]);
    }else{
    $post->desc=$request->desc;
    $post->title=$request->title;
    $post->update();
    return response()->json([
        "success"=>true,
        'edit'=>'post edited',
        "message"=>$this->posts()

        ]);
    }
    }

    //////////delete//////////////
    public function delete(Request $request){

    $post=Post::find($request->id);
 
  
    if($post->photo!=''){
        Storage::delete('public/posts/'.$post->photo);
    }
    $post->delete();
        return response()->json([
        "success"=>true,
        "message"=>"is deleted"
        ]);
   
        
    }

    
}
