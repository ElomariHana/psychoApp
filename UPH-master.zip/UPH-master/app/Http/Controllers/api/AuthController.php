<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Tymon\JWTAuth\Facades\JWTAuth;

class AuthController extends Controller
{
    public function login(Request $request) {
        // get email and password from request
        $credentials = $request->only(['email', 'password']);
        
        // try to auth and get the token using api authentication
        if (!$token = auth()->attempt($credentials)) {
            // if the credentials are wrong we send an unauthorized error in json format
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        return response()->json([
            //'expires' => auth('api')->factory()->getTTL() * 60 // time to expiration
            'success' =>true,
            'token' => $token,
            'user' => Auth::user()
            
        ]);
    }

    public function register(Request $request){

        $CryptPass=Hash::make($request->password);
        $user= new User;
        try{

            $user->name=$request->name;
            $user->email=$request->email;
            $user->password=$CryptPass;
            $user->save();
            return $this->login($request);

        }catch(Exception $e){
            return response()->json([
            'success'=>false,
            'error'=>$e
           ]);
        }
    }

    public function logout(Request $request){
        try{
            JWTAuth::Invalidate(JWTAuth::parseToken($request->token));
            return response()->json(
            [
            'success'=>true,
            'message'=>'logout success',
            ]
            );
        }catch(Exception $e){
        return response()->json(
            [
            'success'=>False,
            'message'=>'logout faild',
            ]
            );
        }
    }

    public function getAllUsers(){
     $users = User::all();
        return response()->json(
        [
            'success'=>true,
            'user'=>$users,

        ]
        );
    }

    public function saveUserInfo(Request $request){
        $user=  User::find(Auth::user()->id);
        $photo = '';
        if($request->photo!=''){
        $photo=time().'.jpg';
        file_put_contents('storage/profiles/'.$photo,base64_decode($request->photo));
        $user->photo=$photo;
        }

        $user->role= $request->role;
        $user->update();
        
        // sheck if the user is a student or professor to ad the CODE values as a CNE or a Matricule values 
        if($request->role == 'Professor'){
            // add the 'matricule to prof
            $profController = new ProfController;
            $profController->create($request->code , $user->id);
        }
        else{
            // add the 'CNE' to Etudiant 
            $etudiantController = new EtudiantController;
            $etudiantController->create($request->code , $user->id);
        }
        return response()->json([
            'success'=>true,
            'photo'=>$photo,
            'user'=>$user
            
           ]);

    }
}