<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Etudiant;
use DB;

class EtudiantController extends Controller
{
    //Select
    public function etudiants(){
        $etudiants=Etudiant::all();

         $etudiants = DB::table('users')
            ->join('etudiants','users.id', '=', 'etudiants.user_id')
            /*->where('archives.id','=',$id)*/
            ->get();
    	return response()->json([
                    'success'=>true,
                    'etudiants'=>$etudiants
                ]); 
    }
    
    //Create
    public function create($CNE , $user_id){
    	$etudiant= new Etudiant;
    	$etudiant->user_id= $user_id;
    	$etudiant->CNE= $CNE;
    	$etudiant->save();

    	 return response()->json([
                    'success'=>true,
                    'etudiant'=>$etudiant
                ]); 
    }

    //Update

    public function update(Request $req,Etudiant $id ){
    	$etudiant=Etudiant::find($req->id);
    	$etudiant->user_id=$req->user_id;
    	$etudiant->CNE=$req->CNE;
    	$etudiant->update();
    	return response()->json([
    		'success'=>true,
    		'etudiant'=>$etudiant
    	]);

    }

    //Delete
    public function delete(Request $req, Etudiant $id){
    	$etudiant=Etudiant::find($req->id);
    	$etudiant->delete();
    	return response()->json([
    		'message'=>'deleted'
    	]);
    }

}
