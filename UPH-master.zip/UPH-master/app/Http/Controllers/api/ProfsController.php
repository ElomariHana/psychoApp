<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ProfsController extends Controller
{
    //create
    public function create(Request $request){
        $prof = new Prof;
        $prof->id_user=Auth::user()->id; 
        $etudiante->matricule = $request->matricule;
        $classeur->save();
        $classeur->user;

        return response()->json ([
            
            'success' => true,
            'message' => 'prof added'
        ]);
    }
}
