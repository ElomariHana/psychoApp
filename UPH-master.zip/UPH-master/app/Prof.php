<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;
use App\Archif;
class Prof extends Model
{
    public function user(){
        return $this->belongsTo(User::class);
    }
    public function archifs(){
       return $this->hasMany(Archif::class);
}
}
