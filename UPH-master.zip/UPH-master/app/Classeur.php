<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Archif;
use App\File;
class Classeur extends Model
{
    public function archifs(){
        return $this->belongsTo(Archif::class);
    }
    public function files(){
        return $this->hasMany(File::class);
 }
}
