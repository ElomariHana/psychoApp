<?php

namespace App;
use App\User;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
   public function user(){
        return $this->belongsTo('App\user');
   }
   
   public function comments()
    {
        return $this->morphMany('App\Comment', 'commentable')->latest();
    }
    public function likes()
    {
        return $this->hasMany('App\Like');
    }


}
