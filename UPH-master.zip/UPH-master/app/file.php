<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Classeur;
class file extends Model
{
    //
    public function classeur(){
        return $this->belongsTo(Classeur::class);
    }
}
