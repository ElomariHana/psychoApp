<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Archif;
use App\User;

class Etudiant extends Model
{
    public function user(){
        return $this->belongsTo(User::class);
    }
    public function archifs(){
       return $this->hasMany(Archif::class);
    }
}