<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Etudiante;
use App\Prof;
use App\Classeur;
class Archif extends Model
{
    protected $guarded = [];
    public function etudiante(){
        return $this->belongsTo(Etudiante::class);
    }
    public function prof(){
        return $this->belongsTo(Prof::class);
    }
    public function classeurs(){
        return $this->hasMany(Classeur::class);
 }
}
